// Lógica simple de reservas usando localStorage
(function(){
  const STORAGE_KEY = 'barber_bookings';

  // Elementos
  const form = document.getElementById('bookingForm');
  const nameInput = document.getElementById('name');
  const phoneInput = document.getElementById('phone');
  const serviceInput = document.getElementById('service');
  const dateInput = document.getElementById('date');
  const timeSelect = document.getElementById('time');
  const bookingsList = document.getElementById('bookingsList');
  const noBookings = document.getElementById('noBookings');
  const message = document.getElementById('message');

  function getBookings(){
    try{
      return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    }catch(e){
      console.error('Error parseando bookings', e);
      return [];
    }
  }
  function saveBookings(bookings){
    localStorage.setItem(STORAGE_KEY, JSON.stringify(bookings));
  }

  function renderBookings(){
    const bookings = getBookings();
    bookingsList.innerHTML = '';
    if(bookings.length === 0){
      noBookings.style.display = 'block';
      return;
    }
    noBookings.style.display = 'none';
    bookings.sort((a,b)=>a.timeStamp-b.timeStamp);
    bookings.forEach(bk =>{
      const li = document.createElement('li');
      li.className = 'booking-item';
      const meta = document.createElement('div');
      meta.className = 'booking-meta';
      meta.innerHTML = `<strong>${escapeHtml(bk.name)}</strong> — ${escapeHtml(bk.service)}<br><span class="muted">${escapeHtml(bk.date)} ${escapeHtml(bk.time)} • ${escapeHtml(bk.phone)}</span>`;
      const actions = document.createElement('div');
      actions.className = 'booking-actions';
      const btn = document.createElement('button');
      btn.textContent = 'Cancelar';
      btn.dataset.id = bk.id;
      btn.addEventListener('click', ()=>{ deleteBooking(bk.id); });
      actions.appendChild(btn);
      li.appendChild(meta);
      li.appendChild(actions);
      bookingsList.appendChild(li);
    });
  }

  function showMessage(txt, type='info'){
    message.textContent = txt;
    message.className = type === 'error' ? 'error' : 'success';
    setTimeout(()=>{ message.textContent = ''; message.className = ''; }, 3500);
  }

  function generateTimeOptions(startHour=9, endHour=18, intervalMin=30){
    timeSelect.innerHTML = '<option value="">Seleccioná una hora</option>';
    for(let h=startHour; h<=endHour; h++){
      for(let m=0; m<60; m+=intervalMin){
        const hh = String(h).padStart(2,'0');
        const mm = String(m).padStart(2,'0');
        const val = `${hh}:${mm}`;
        const opt = document.createElement('option');
        opt.value = val;
        opt.textContent = val;
        timeSelect.appendChild(opt);
      }
    }
  }

  function deleteBooking(id){
    const bookings = getBookings().filter(b=>String(b.id)!==String(id));
    saveBookings(bookings);
    renderBookings();
    showMessage('Turno cancelado', 'info');
  }

  function escapeHtml(str){
    return String(str).replace(/[&<>"']/g, function(s){
      return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s]);
    });
  }

  function onSubmit(e){
    e.preventDefault();
    const name = nameInput.value.trim();
    const phone = phoneInput.value.trim();
    const service = serviceInput.value;
    const date = dateInput.value;
    const time = timeSelect.value;

    if(!name || !phone || !service || !date || !time){
      showMessage('Completá todos los campos', 'error');
      return;
    }

    // validar fecha no pasada
    const today = new Date();
    today.setHours(0,0,0,0);
    const selected = new Date(date + 'T00:00:00');
    if(selected < today){
      showMessage('La fecha seleccionada ya pasó', 'error');
      return;
    }

    // evitar solapamientos (mismo día y hora)
    const bookings = getBookings();
    const conflict = bookings.find(b=>b.date===date && b.time===time);
    if(conflict){
      showMessage('Esa fecha y hora ya está reservada. Elegí otra.', 'error');
      return;
    }

    const booking = {
      id: Date.now().toString(36),
      name,
      phone,
      service,
      date,
      time,
      timeStamp: Date.now()
    };
    bookings.push(booking);
    saveBookings(bookings);
    renderBookings();
    form.reset();
    // volver a fijar fecha mínima si se reseteó
    setMinDate();
    showMessage('Turno confirmado ✅', 'info');
  }

  function setMinDate(){
    const today = new Date();
    const iso = today.toISOString().slice(0,10);
    dateInput.min = iso;
  }

  // Inicialización
  document.addEventListener('DOMContentLoaded', ()=>{
    generateTimeOptions(9,17,30); // horario 09:00 - 17:30
    setMinDate();
    renderBookings();
    form.addEventListener('submit', onSubmit);
  });

})();
